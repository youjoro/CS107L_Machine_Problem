﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class Cart_WishList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["logged_in"] == null)
        {
            remove_item.Visible = true;
        }
        else
        {
            string item_placeholder = "", get_item = get_items(item_placeholder);
            string[] list_items = get_item.Split(',');
            foreach (string t in list_items)
            {
                if (t != " ")
                {
                    remove_item.Visible = true;
                    items_list.Items.Add(t);
                }
            }
        }
    }

    public string get_items(string item)
    {
        string username = Session["logged_in"].ToString();
        string connstr = "Provider=Microsoft.Jet.OleDB.4.0; Data Source=";
        connstr += Server.MapPath("~/App_Data/Database-Ani_Hub.mdb");
        OleDbConnection conn = new OleDbConnection(connstr);
        conn.Open();
        OleDbCommand cmd = new OleDbCommand("select * from accounts where Username =@Email", conn);
        cmd.Parameters.AddWithValue("@Email", username);
        OleDbDataReader reader = cmd.ExecuteReader();

        while (reader.Read())
        {
            string wishlist = reader.GetValue(2).ToString();
            // Insert code to process data.
            item = wishlist;

        }
        reader.Close();

        conn.Close();
        return item;
    }
    protected void remove_item_Click(object sender, EventArgs e)
    {
        List<string> chosen = new List<string> { };
        if (items_list.SelectedIndex != -1)
        {
            for (int i = 0; i < items_list.Items.Count; i++)
            {
                if (items_list.Items[i].Selected)
                {
                    chosen.Add(items_list.SelectedValue.ToString());
                }
            }
            string item_placeholder = "", get_item = get_items(item_placeholder);
            string[] list_items = get_item.Split(',');

            foreach (string t in list_items)
            {
                int i = 0;
                foreach (string n in chosen)
                {
                    if (n == t)
                    {
                        list_items[i] = "";
                    }
                }
                i++;
            }

            if (Session["logged_in"].ToString() != null)
            {
                string items = "";
                foreach (string t in list_items)
                {
                    items = string.Join(",", t);
                }

                string username = Session["logged_in"].ToString();
                string connstr = "Provider=Microsoft.Jet.OleDB.4.0; Data Source=";
                connstr += Server.MapPath("~/App_Data/Database-Ani_Hub.mdb");

                OleDbConnection conn = new OleDbConnection(connstr);
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "UPDATE accounts SET User_WishList = @new WHERE [Username] = @id";
                cmd.Parameters.AddWithValue("@new", items);
                cmd.Parameters.AddWithValue("@id", username);

                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                {
                    conn.Close();
                }
            }

        }

        Response.Redirect(Request.RawUrl, true);

    }
}