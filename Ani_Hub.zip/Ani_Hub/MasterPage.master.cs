﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void To_Home(object sender, EventArgs e)
    {
        Response.Redirect("http://localhost:52358/Home_Page.aspx");
    }
    protected void To_Items_Click(object sender, EventArgs e)
    {
        Response.Redirect("http://localhost:52358/Browse Items/Items.aspx");
    }
    protected void To_Items_By_Name_Click(object sender, EventArgs e)
    {
        Response.Redirect("http://localhost:52358/Browse Items/Items_By_Name.aspx");
    }
    protected void To_Items_By_Type_Click(object sender, EventArgs e)
    {
        Response.Redirect("http://localhost:52358/Browse Items/Items_By_Type.aspx");
    }
    protected void To_Checkout_Click(object sender, EventArgs e)
    {
        Response.Redirect("http://localhost:52358/Cart/CheckOut.aspx");
    }
    protected void To_Wishlist_Click(object sender, EventArgs e)
    {
        Response.Redirect("http://localhost:52358/Cart/WishList.aspx");
    }
    protected void To_Account_Click(object sender, EventArgs e)
    {
        Response.Redirect("http://localhost:52358/Account/Your_Account.aspx");
    }
    protected void Login_Click(object sender, EventArgs e)
    {
        Response.Redirect("http://localhost:52358/Account/Login.aspx");
    }
    protected void Register_Click(object sender, EventArgs e)
    {
        Response.Redirect("http://localhost:52358/Account/Registration.aspx");
    }
    protected void About_Us_Click(object sender, EventArgs e)
    {
        Response.Redirect("http://localhost:52358/More/About_Us.aspx");
    }
    protected void faq_Click(object sender, EventArgs e)
    {
        Response.Redirect("http://localhost:52358/More/faq.aspx");
    }
}
