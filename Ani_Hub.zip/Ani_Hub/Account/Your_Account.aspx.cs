﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class Account_Your_Account : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["logged_in"] == null)
        {
            btnRegister.Enabled = false;
            update_info.Enabled = false;
        }
        else
        {
            string item_placeholder = "", get_item = get_items(item_placeholder);
            string[] list_items = get_item.Split(',');
            foreach (string t in list_items)
            {
                if (t != " ")
                {
                    remove_item.Visible = true;
                    items_list.Items.Add(t);
                }
            }
        }
    }

    protected void logout_Click(object sender, EventArgs e)
    {
        Session["logged_in"] = null;
    }
    protected void update_info_Click(object sender, EventArgs e)
    {
        acc.Visible = false;
        UpdateInfo.Visible = true; 
    }
    protected void btnRegister_Click(object sender, EventArgs e)
    {
        string username = Session["logged_in"].ToString();
        string connstr = "Provider=Microsoft.Jet.OleDB.4.0; Data Source=";
        connstr += Server.MapPath("~/App_Data/Database-Ani_Hub.mdb");
        OleDbConnection conn = new OleDbConnection(connstr);
        OleDbCommand cmd = new OleDbCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "UPDATE accounts SET User_Email = @email, Username = @username, User_Payment = @payment, User_address = @address, User_Fullname = @name, User_Password = @password WHERE [Username] = @id";
        cmd.Parameters.AddWithValue("@email", Email_Address.Text);
        cmd.Parameters.AddWithValue("@username", Username.Text);
        cmd.Parameters.AddWithValue("@payment", payment.SelectedValue.ToString());
        cmd.Parameters.AddWithValue("@address", address.Text);
        cmd.Parameters.AddWithValue("@name", first_name.Text+", "+last_name.Text);
        cmd.Parameters.AddWithValue("@password", Password.Text);
        cmd.Parameters.AddWithValue("@id", username);

        cmd.Connection = conn;
        conn.Open();
        cmd.ExecuteNonQuery();
        {
            conn.Close();
        }
        
        Session["logged_in"] = Username.Text;
        Username.Text = null;
        address.Text = null;
        first_name.Text = null;
        last_name.Text = null;
        Password.Text = null;
        payment.SelectedIndex = -1;
        acc.Visible = true;
        UpdateInfo.Visible = false; 
    }
    public string get_items(string item)
    {
        string username = Session["logged_in"].ToString();
        string connstr = "Provider=Microsoft.Jet.OleDB.4.0; Data Source=";
        connstr += Server.MapPath("~/App_Data/Database-Ani_Hub.mdb");
        OleDbConnection conn = new OleDbConnection(connstr);
        conn.Open();
        OleDbCommand cmd = new OleDbCommand("select * from accounts where Username =@Email", conn);
        cmd.Parameters.AddWithValue("@Email", username);
        OleDbDataReader reader = cmd.ExecuteReader();

        while (reader.Read())
        {
            string wishlist = reader.GetValue(2).ToString();
            // Insert code to process data.
            item = wishlist;

        }
        reader.Close();

        conn.Close();
        return item;
    }
    protected void remove_item_Click(object sender, EventArgs e)
    {
        List<string> chosen = new List<string>{};
        if (items_list.SelectedIndex != -1)
        {
            for (int i = 0; i < items_list.Items.Count; i++)
            {
                if (items_list.Items[i].Selected)
                {
                    chosen.Add(items_list.SelectedValue.ToString());
                }
            }
            string item_placeholder = "", get_item = get_items(item_placeholder);
            string[] list_items = get_item.Split(',');

            foreach (string t in list_items)
            {
                int i =0;
                foreach (string n in chosen)
                {
                    if (n == t)
                    {
                        list_items[i] = "";
                    }
                }
                i++;
            }

            if (Session["logged_in"].ToString() != null)
            {
                string item = " ";
                string items = list_items.ToString();
                string username = Session["logged_in"].ToString();
                string connstr = "Provider=Microsoft.Jet.OleDB.4.0; Data Source=";
                connstr += Server.MapPath("~/App_Data/Database-Ani_Hub.mdb");

                OleDbConnection conn = new OleDbConnection(connstr);
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "UPDATE accounts SET User_WishList = @new WHERE [Username] = @id";
                cmd.Parameters.AddWithValue("@new", items);
                cmd.Parameters.AddWithValue("@id", username);

                cmd.Connection = conn;
                conn.Open();
                cmd.ExecuteNonQuery();
                {
                    conn.Close();
                }
            }

        }

        Response.Redirect(Request.RawUrl, true);

    }
}