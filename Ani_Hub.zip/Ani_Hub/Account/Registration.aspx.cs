﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string connstr = "Provider=Microsoft.Jet.OleDB.4.0; Data Source=";
        connstr += Server.MapPath("~/App_Data/Database-Ani_Hub.mdb");
        OleDbConnection conn = new OleDbConnection(connstr);
        conn.Open();
        string name = first_name.Text +", "+ last_name.Text;
        OleDbCommand cmd = new OleDbCommand("insert into accounts values('" + Email_Address.Text + "','" + Username.Text + "','" + "none" + "','" + payment.SelectedValue.ToString() + "','" + address.Text + "','" + "no" + "','" + "n" + "','" + Password.Text + "','" + name + "');", conn);
        cmd.ExecuteNonQuery();
        conn.Close();

        Email_Address.Text = null;
        first_name.Text = null;
        last_name.Text = null;
        Username.Text = null;
        address.Text = null;
        payment.SelectedIndex = -1;
        Response.Write("<script>alert('Form has been sent successfully')</script>");
    }
}