﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Web.UI.HtmlControls;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

    }

    protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
    {
        string connstr = "Provider=Microsoft.Jet.OleDB.4.0; Data Source=";
        connstr += Server.MapPath("~/App_Data/Database-Ani_Hub.mdb");
        OleDbConnection conn = new OleDbConnection(connstr);
        conn.Open();
        OleDbCommand cmd = new OleDbCommand("select * from accounts where Username =@Email and User_Password =@Password", conn);
        cmd.Parameters.AddWithValue("@Email", Login1.UserName );
        cmd.Parameters.AddWithValue("@Password", Login1.Password);
        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            Session["logged_in"] = Login1.UserName;
            Response.Redirect("http://localhost:52358/Account/Your_Account.aspx");
        }
        conn.Close();

    }
    protected void To_account_Click(object sender, EventArgs e)
    {
        Response.Redirect("http://localhost:52358/Account/Your_Account.aspx");
    }
    protected void To_wishlist_Click(object sender, EventArgs e)
    {
        Response.Redirect("http://localhost:52358/Cart/WishList.aspx");
    }
}