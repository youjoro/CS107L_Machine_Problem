﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class Browse_Items_View_Item : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["logged_in"] == null)
        {
            acc.Visible = true;
        to_wishlist.Enabled = false;  
        }
    }


    protected void to_wishlist_Click(object sender, EventArgs e)
    {
        string[] item_id = Request.QueryString.ToString().Split('=');
        string username = Session["logged_in"].ToString();

        string added_items = get_items(item_id[1]);
        string connstr = "Provider=Microsoft.Jet.OleDB.4.0; Data Source=";
        connstr += Server.MapPath("~/App_Data/Database-Ani_Hub.mdb");
        OleDbConnection conn = new OleDbConnection(connstr);
        OleDbCommand cmd = new OleDbCommand();
        cmd.CommandType = CommandType.Text;

        cmd.CommandText = "UPDATE accounts SET User_WishList = @item_id WHERE [Username] = @id";
        cmd.Parameters.AddWithValue("@item_id", added_items);
        cmd.Parameters.AddWithValue("@id",username);
        cmd.Connection = conn;
        conn.Open();
        cmd.ExecuteNonQuery();
        {
            conn.Close();
        }
        
    }
    public string get_items(string item)
    {
        string username = Session["logged_in"].ToString();
        string connstr = "Provider=Microsoft.Jet.OleDB.4.0; Data Source=";
        connstr += Server.MapPath("~/App_Data/Database-Ani_Hub.mdb");
        OleDbConnection conn = new OleDbConnection(connstr);
        conn.Open();
        OleDbCommand cmd = new OleDbCommand("select * from accounts where Username =@Email", conn);
        cmd.Parameters.AddWithValue("@Email", username);
        OleDbDataReader reader = cmd.ExecuteReader();

        while (reader.Read())
        {
            string wishlist = reader.GetValue(2).ToString();
            
            // Insert code to process data.
            string []items = wishlist.Split(',');
            string end = items[0].ToString();
            if (wishlist != "")
            {
                end = items[items.Length - 1].ToString();
            }
            foreach(string t in items)
            {   
                if (item==t)
                {                    
                    item = wishlist;
                    break;
                }
                else if (t == "")
                {
                    break;
                }
                
                else if(t == end)
                {
                    item = item + ',' + wishlist;
                }
            }
            
        }
        reader.Close();

        conn.Close();
        return item;
    }
}